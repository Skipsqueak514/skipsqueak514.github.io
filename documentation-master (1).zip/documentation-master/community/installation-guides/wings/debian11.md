# Debian 11

## Install

There is no additional configuration required for Wings on Debian 11. You can follow the [official Wings install documentation](/wings/1.0/installing.md), which covers Docker installation for Debian.
