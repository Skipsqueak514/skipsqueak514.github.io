# Upgrading

::: danger This Software is Abandoned
This documentation is for **abandoned software** which does not recieve any security updates or support
from the community. This documentation has been left accessible for historial reasons.

You should be installing and using [Wings](/wings/1.0/installing.md) in production environments with
[Pterodactyl Panel 1.0](/panel/1.0/getting_started.md).
:::

## Version Specific Guides
* [0.4.X to 0.5.X](upgrade/0.4_to_0.5.md)
* [0.5.X series](upgrade/0.5.md)
* [0.5.X to 0.6.X](upgrade/0.5_to_0.6.md)
* [0.6.X series](upgrade/0.6.md)
* [0.6.X to 1.X.X](/wings/1.0/migrating.md) <Badge text="current" vertical="middle"/>
* [1.X.X series](/wings/1.0/upgrading.md) <Badge text="current" vertical="middle"/>
